﻿using Microsoft.EntityFrameworkCore;
using System.Diagnostics.Metrics;

namespace ReactAspCrud.Models
{
    public class studentDbContext : DbContext
    {
        public studentDbContext(DbContextOptions<studentDbContext> options) : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=SAKSHI;Initial Catalog=login;Integrated Security=True;TrustServerCertificate=True");
            }
        }
    }
}


