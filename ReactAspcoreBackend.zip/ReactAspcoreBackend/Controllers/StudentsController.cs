﻿using Microsoft.AspNetCore.Http;

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ReactAspCrud.Models;

namespace ReactAspCrud.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {

    private readonly studentDbContext _studentDbContext;

    public StudentsController (studentDbContext studentDbContext)

        {
            _studentDbContext = studentDbContext;   
        }

       
        [HttpPost]
        [Route("AddStudent")]
        public async Task<Student> AddStudent(Student objStudent)

        {
            _studentDbContext.Students.Add(objStudent);
            await _studentDbContext.SaveChangesAsync();
            return objStudent;
        }
       
        

    }
}


